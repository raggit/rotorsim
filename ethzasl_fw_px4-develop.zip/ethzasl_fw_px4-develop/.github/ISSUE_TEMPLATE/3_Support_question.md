---
name: ⛔ Support Question
about: See [PX4 Discuss](http://discuss.px4.io/) for questions about using PX4.

---

We use GitHub issues only to discuss PX4 bugs and new features. For
questions about using PX4 or related components, please use [PX4 Discuss](http://discuss.px4.io/).

Thanks!
