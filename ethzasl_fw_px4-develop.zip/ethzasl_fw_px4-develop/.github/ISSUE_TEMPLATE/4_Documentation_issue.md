---
name: ⛔ Documentation Issue
about: See https://github.com/PX4/Devguide for documentation issues

---

PX4 has dedicated repositories for developer documentation (https://github.com/PX4/Devguide) and user documentation (https://github.com/PX4/px4_user_guide).

Thanks!
