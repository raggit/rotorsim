#!/usr/bin/env bash

ulimit -S -n 2048
